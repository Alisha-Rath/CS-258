#ifndef HeaderDns_H
#define HeaderDns_H

#include "BufferBytePacket.hpp"
#include "Utils.hpp"
#include <cstdint>

// Enum representing DNS response codes
enum RCode
{
    NOERROR,  // 0
    FORMERR,  // 1
    SERVFAIL, // 2
    NXDOMAIN, // 3
    NOTIMP,   // 4
    REFUSED   // 5
};

// Class representing the DNS header
class HeaderDns
{
public:
    // Header fields
    uint16_t pid;                  // Packet ID
    bool queryResponse;            // Query or Response flag
    uint8_t opcode;                // Operation code
    bool authoritativeAns;         // Authoritative Answer flag
    bool truncatedMsg;             // Truncated Message flag
    bool recursionDesired;         // Recursion Desired flag
    bool recursionAvailable;       // Recursion Available flag
    bool Z;                        // Reserved (Zero) flag
    RCode responseCode;            // Response code
    bool checkingDisabled;         // Checking Disabled flag
    bool authedData;               // Authenticated Data flag
    uint16_t questions;            // Number of questions
    uint16_t answers;              // Number of answers
    uint16_t authoritativeEntries; // Number of authoritative entries
    uint16_t resourceEntries;      // Number of resource entries

    // Constructor initializing all fields to default values
    HeaderDns()
        : pid(0), recursionDesired(false), truncatedMsg(false), authoritativeAns(false), opcode(0), queryResponse(false), responseCode(RCode::NOERROR), checkingDisabled(false), authedData(false), Z(false), recursionAvailable(false), questions(0), answers(0), authoritativeEntries(0), resourceEntries(0) {}

    // Method to read DNS header from buffer
    void read(BufferBytePacket &buffer);

    // Method to write DNS header to buffer
    void write(BufferBytePacket &buffer) const;

    // Overloaded stream insertion operator to output DNS header
    friend std::ostream &operator<<(std::ostream &os, const HeaderDns &header);
};

#endif // HeaderDns_H
