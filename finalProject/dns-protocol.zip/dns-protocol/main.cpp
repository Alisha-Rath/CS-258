#include <iostream>
#include <fstream>
#include <vector>
#include "BufferBytePacket.hpp"
#include "PacketDns.hpp"
#include "UDPClient.hpp"
#include "ProxyDns.hpp"

int main(int argc, const char **argv)
{
    // Check if the correct number of arguments is provided
    if (argc != 2)
    {
        std::cout << "Usage: <executable-name> <binding-port-num>" << std::endl;
        return 0;
    }

    // Set the IP address to listen on
    std::string addr = "0.0.0.0";
    // Parse the port number from command line arguments
    int port = std::stoi(argv[1]);

    // Create an instance of UDPClient for handling UDP connections
    UDPClient udpClient;
    // Bind the UDP client to the specified address and port
    udpClient.bind(addr, port);

    // Create an instance of ProxyDns for handling DNS proxy requests
    ProxyDns proxy;

    // Print a message indicating that the DNS server is listening on the specified port
    std::cout << "DNS server listening on " << port << "..." << std::endl;

    // Continuously handle DNS requests
    do
    {
        try
        {
            // Handle incoming DNS requests using the proxy
            proxy.handleRequest(udpClient);
        }
        catch (std::exception &e)
        {
            // Catch any exceptions that occur during request handling
            // (For example, if the proxy encounters an error)
        }
    } while (true);

    return 0;
}
