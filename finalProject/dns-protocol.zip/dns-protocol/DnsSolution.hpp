#ifndef DnsSolution_H
#define DnsSolution_H

#include <unordered_map>
#include <cstdint>
#include "QueryDns.hpp"
#include "BufferBytePacket.hpp"
#include "Utils.hpp"

// Abstract class representing a DNS solution
class DnsSolution
{
public:
    // Factory method to create a DNS answer for unknown query types
    static DnsSolution *createDnsAns(std::string &domain, uint16_t queryType, uint16_t dataLen, uint32_t ttl);
    // Factory method to create a DNS answer for MX query types
    static DnsSolution *createDnsAns(std::string &domain, uint16_t priority, std::string &host, uint32_t ttl);
    // Factory method to create a DNS answer for known query types (A, AAAA, NS, CNAME)
    static DnsSolution *createDnsAns(std::string &domain, std::string &addr, uint32_t ttl,
                                     QueryType::QueryTypeEnum qtype);
    // Method to read a DNS response from a buffer
    static DnsSolution *read(BufferBytePacket &buffer);
    // Method to construct an IPv4 address string from raw IP
    static void constructIPv4Addr(uint32_t rawIP, std::string &addr);
    // Virtual method to format the DNS solution for output stream
    virtual std::ostream &format(std::ostream &os) const { return os; }
    // Friend function to output DNS solution to stream
    friend std::ostream &operator<<(std::ostream &os, const DnsSolution *obj) { return obj->format(os); }
    // Method to convert IPv4 address string to raw IP
    static uint32_t deconstructIPv4Addr(const std::string &addr);
    // Virtual method to write DNS solution to buffer
    virtual unsigned write(BufferBytePacket &buffer) const = 0;
    // Method to construct an IPv6 address string from raw IP
    static void constructIPv6Addr(__uint128_t rawIP, std::string &addr);
    // Method to convert IPv6 address string to raw IP
    static __uint128_t deconstructIPv6Addr(const std::string &addr);
};

// Class representing an unknown DNS solution
class UnknownDnsSolution : public DnsSolution
{
private:
    std::string domain;
    uint16_t queryType;
    uint16_t dataLen;
    uint32_t ttl;

public:
    UnknownDnsSolution(std::string &domain, uint16_t queryType, uint16_t dataLen, uint32_t ttl)
        : domain(domain), queryType(queryType), dataLen(dataLen), ttl(ttl) {}

    std::ostream &format(std::ostream &os) const override;
    unsigned write(BufferBytePacket &buffer) const override;
};

// Class representing an A type DNS solution
class ATypeDnsSolution : public DnsSolution
{
private:
    std::string domain;
    std::string addr;
    uint32_t ttl;

public:
    ATypeDnsSolution(std::string &domain, std::string &addr, uint32_t ttl)
        : domain(domain), addr(addr), ttl(ttl) {}

    std::ostream &format(std::ostream &os) const override;
    unsigned write(BufferBytePacket &buffer) const override;
    [[nodiscard]] std::string getIPAddr() const { return addr; }
    [[nodiscard]] std::string getDomain() const { return domain; }
};

// Class representing an NS type DNS solution
class NSTypeDnsSolution : public DnsSolution
{
private:
    std::string domain;
    std::string host;
    uint32_t ttl;

public:
    NSTypeDnsSolution(std::string &domain, std::string &host, uint32_t ttl)
        : domain(domain), host(host), ttl(ttl) {}

    std::ostream &format(std::ostream &os) const override;
    unsigned write(BufferBytePacket &buffer) const override;
    [[nodiscard]] std::string getDomain() const { return domain; }
    [[nodiscard]] std::string getHost() const { return host; }
};

// Class representing a CNAME type DNS solution
class CNameTypeDnsSolution : public DnsSolution
{
private:
    std::string domain;
    std::string host;
    uint32_t ttl;

public:
    CNameTypeDnsSolution(std::string &domain, std::string &host, uint32_t ttl)
        : domain(domain), host(host), ttl(ttl) {}

    std::ostream &format(std::ostream &os) const override;
    unsigned write(BufferBytePacket &buffer) const override;
};

// Class representing an MX type DNS solution
class MXTypeDnsSolution : public DnsSolution
{
private:
    std::string domain;
    uint16_t priority;
    std::string host;
    uint32_t ttl;

public:
    MXTypeDnsSolution(std::string &domain, uint16_t priority, std::string &host, uint32_t ttl)
        : domain(domain), priority(priority), host(host), ttl(ttl) {}

    std::ostream &format(std::ostream &os) const override;
    unsigned write(BufferBytePacket &buffer) const override;
};

// Class representing an AAAA type DNS solution
class AAAATypeDnsSolution : public DnsSolution
{
private:
    std::string domain;
    std::string ipv6addr;
    uint32_t ttl;

public:
    AAAATypeDnsSolution(std::string &domain, std::string &addr, uint32_t ttl)
        : domain(domain), ipv6addr(addr), ttl(ttl) {}

    std::ostream &format(std::ostream &os) const override;
    unsigned write(BufferBytePacket &buffer) const override;
};

#endif
