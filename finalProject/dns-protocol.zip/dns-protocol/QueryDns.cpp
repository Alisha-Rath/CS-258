#include "QueryDns.hpp"
#include <iostream>

// Static initialization of the query number
uint16_t QueryType::qNum = 1;

// Read method implementation
void QueryDns::read(BufferBytePacket &buffer)
{
    // Read the domain name from the buffer
    buffer.readDomainName(name);
    // Convert the read query type to enum
    qType = QueryType::toEnum(buffer.read2Bytes());
    // Skip reading the class (2 bytes) as it's not used
    buffer.read2Bytes();
}

// Overloaded stream insertion operator implementation
std::ostream &operator<<(std::ostream &os, const QueryDns &question)
{
    // Print the query details
    return os << "QueryDns {" << std::endl
              << "\tname: " << question.name << std::endl
              << "\tqueryType: " << question.qType << std::endl
              << "}" << std::endl;
}

// Write method implementation
void QueryDns::write(BufferBytePacket &buffer) const
{
    // Write the domain name to the buffer
    buffer.writeDomainName(name);
    // Write the query type as its numeric value
    buffer.write2Bytes(QueryType::toNum(qType));
    // Write the class, which is always set to 1
    buffer.write2Bytes(1);
}
