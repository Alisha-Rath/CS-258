#ifndef UTILS_H
#define UTILS_H

#include <string>

// Convert an index to an enumeration value
template <class T>
T enumFromIdx(unsigned i)
{
    return static_cast<T>(i);
}

// Convert an enumeration value to an index
template <class T>
unsigned idxFromEnum(T t)
{
    return T(t);
}

// Check if a string ends with a specific substring
bool hasEnding(std::string const &fullString, std::string const &ending);

#endif // UTILS_H