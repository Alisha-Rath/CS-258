#ifndef UDP_CLIENT_H
#define UDP_CLIENT_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdexcept>
#include <string>
#include <arpa/inet.h>
#include "BufferBytePacket.hpp"

class UDPClient
{
public:
    UDPClient();
    ~UDPClient();

    // Send data over UDP to a specified address and port
    ssize_t send(const BufferBytePacket &buffer, std::string &sendToAddr, int sendToPort);

    // Receive data from UDP socket
    std::pair<ssize_t, std::pair<std::string, int>> recv(BufferBytePacket &buffer);

    // Bind the UDP socket to a specific address and port
    void bind(std::string &addr, int port);

private:
    int udpSocket;
};

#endif
