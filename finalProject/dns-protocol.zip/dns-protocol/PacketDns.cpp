#include "PacketDns.hpp"

void PacketDns::packetFromBuffer(BufferBytePacket &buffer)
{
    // Read the DNS header from the buffer
    header.read(buffer);

    unsigned i;

    // Read DNS questions from the buffer
    for (i = 0; i < header.questions; i++)
    {
        QueryDns question("", QueryType::QueryTypeEnum::UNKNOWN);
        question.read(buffer);
        questions.push_back(question);
    }

    // Read DNS answers from the buffer
    for (i = 0; i < header.answers; i++)
    {
        DnsSolution *answer;
        answer = DnsSolution::read(buffer);
        answers.push_back(answer);
    }

    // Read authoritative DNS answers from the buffer
    for (i = 0; i < header.authoritativeEntries; i++)
    {
        DnsSolution *authAns;
        authAns = DnsSolution::read(buffer);
        authorities.push_back(authAns);
    }

    // Read resource DNS answers from the buffer
    for (i = 0; i < header.resourceEntries; i++)
    {
        DnsSolution *resAns;
        resAns = DnsSolution::read(buffer);
        resources.push_back(resAns);
    }
}

void PacketDns::write(BufferBytePacket &buffer)
{
    // Update header counts based on the size of data vectors
    header.questions = questions.size();
    header.answers = answers.size();
    header.authoritativeEntries = authorities.size();
    header.resourceEntries = resources.size();

    // Write the DNS header to the buffer
    header.write(buffer);

    // Write DNS questions, answers, authorities, and resources to the buffer
    for (const auto &i : questions)
        i.write(buffer);
    for (const auto &i : answers)
        i->write(buffer);
    for (const auto &i : authorities)
        i->write(buffer);
    for (const auto &i : resources)
        i->write(buffer);
}

std::ostream &operator<<(std::ostream &os, const PacketDns &packet)
{
    // Write the DNS header to the output stream
    os << packet.header << std::endl;

    // Write DNS questions to the output stream
    for (const auto &q : packet.questions)
        os << q;
    os << std::endl;

    // Write DNS answers to the output stream
    for (const auto &q : packet.answers)
        os << q;
    os << std::endl;

    // Write authoritative DNS answers to the output stream
    for (const auto &q : packet.authorities)
        os << q;
    os << std::endl;

    // Write resource DNS answers to the output stream
    for (const auto &q : packet.resources)
        os << q;
    os << std::endl;

    return os;
}

std::string PacketDns::getRandomARecord()
{
    // Retrieve a random A record from the DNS answers
    for (const auto &q : answers)
    {
        auto *ans = dynamic_cast<ATypeDnsSolution *>(q);
        if (ans == nullptr)
            continue;
        else
        {
            return ans->getIPAddr();
        }
    }
    return "";
}

std::vector<std::pair<std::string, std::string>> PacketDns::getAllNameServers(const std::string &domainName)
{
    // Get all name servers for a given domain name
    std::vector<std::pair<std::string, std::string>> ns;
    for (const auto &q : authorities)
    {
        auto *ans = dynamic_cast<NSTypeDnsSolution *>(q);
        if (ans == nullptr)
            continue;
        else
        {
            std::string domain = ans->getDomain();
            if (!hasEnding(domainName, domain))
                continue;
            ns.emplace_back(domain, ans->getHost());
        }
    }
    return ns;
}

std::string PacketDns::getResolvedNS(const std::string &domain)
{
    // Get the resolved name server IP address for a given domain
    std::vector<std::pair<std::string, std::string>> nameServers = getAllNameServers(domain);
    for (const auto &res : resources)
    {
        auto *ans = dynamic_cast<ATypeDnsSolution *>(res);
        if (ans == nullptr)
            continue;
        std::string domainName = ans->getDomain();
        for (const auto &ns : nameServers)
        {
            if (domainName == ns.second)
            {
                return ans->getIPAddr();
            }
        }
    }
    return "";
}

std::string PacketDns::getUnresolvedNS(const std::string &domain)
{
    // Get the unresolved name server IP address for a given domain
    std::vector<std::pair<std::string, std::string>> nameServers = getAllNameServers(domain);
    if (!nameServers.empty())
        return nameServers[0].second;
    return "";
}
