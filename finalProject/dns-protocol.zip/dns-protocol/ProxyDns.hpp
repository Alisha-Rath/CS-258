#ifndef ProxyDns_H
#define ProxyDns_H

#include <string>
#include <iostream>
#include "QueryDns.hpp"
#include "UDPClient.hpp"
#include "PacketDns.hpp"
#include "BufferBytePacket.hpp"

class ProxyDns
{
private:
    // Private member functions
    bool validateInput(std::string &recordType, QueryType::QueryTypeEnum qtype);
    PacketDns performLookup(std::string &domain, QueryType::QueryTypeEnum qtype, std::string &serverIP);
    PacketDns recursiveResolve(std::string &domain, QueryType::QueryTypeEnum qtype);

public:
    // Public member function
    /**
     * @brief Handles incoming DNS requests from clients.
     * @param udpSocket UDPClient object representing the UDP socket.
     */
    void handleRequest(UDPClient &udpSocket);
};

#endif // ProxyDns_H
