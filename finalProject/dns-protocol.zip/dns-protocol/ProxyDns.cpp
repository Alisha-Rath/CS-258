#include "ProxyDns.hpp"
#include <fstream>

bool ProxyDns::validateInput(std::string &recordType, QueryType::QueryTypeEnum qtype)
{
    // Check if recordType contains only digits
    if (!std::all_of(recordType.begin(), recordType.end(), ::isdigit))
    {
        std::cout << "<record-type> should only contain digits" << std::endl;
        return false;
    }

    // Check if qtype is a known type
    if (qtype == QueryType::QueryTypeEnum::UNKNOWN)
    {
        std::cout << "<record-type> can be either 1, 2, 5, 15, 28" << std::endl;
        return false;
    }

    return true;
}

PacketDns ProxyDns::performLookup(std::string &domain, QueryType::QueryTypeEnum qtype, std::string &serverIP)
{
    // DNS server configuration
    int servport = 53; // DNS UDP port
    std::string servaddr = serverIP;

    // Set up UDP client
    UDPClient udp;
    std::string bindAddr = "0.0.0.0";
    udp.bind(bindAddr, 43210);
    PacketDns packet;

    // Prepare DNS query packet
    packet.header.pid = 45769;
    packet.header.questions = 1;
    packet.header.authedData = true;
    QueryDns ques(domain, qtype);
    packet.questions.push_back(ques);

    // Send DNS query packet to resolver
    std::cout << "Forwarding proxy packet to DNS resolver...\n"
              << packet << std::endl;
    BufferBytePacket reqbuffer;
    packet.write(reqbuffer);
    std::cout << "Bytes sent: " << udp.send(reqbuffer, servaddr, servport) << std::endl;

    // Receive response from resolver
    BufferBytePacket resbuffer;
    std::pair<ssize_t, std::pair<std::string, int>> source = udp.recv(resbuffer);
    std::cout << "Bytes received: " << source.first << std::endl;

    // Parse response packet
    PacketDns respacket;
    respacket.packetFromBuffer(resbuffer);
    std::cout << "Response received from DNS resolver...\n"
              << respacket << std::endl;
    return respacket;
}

void ProxyDns::handleRequest(UDPClient &udpSocket)
{
    // Receive DNS query packet from client
    BufferBytePacket requestBuffer;
    std::pair<ssize_t, std::pair<std::string, int>> source = udpSocket.recv(requestBuffer);

    // Parse request packet
    PacketDns requestPacket;
    requestPacket.packetFromBuffer(requestBuffer);
    std::cout << "Received packet from client...\n"
              << requestPacket << std::endl;

    // Prepare response packet
    PacketDns proxyPacket;
    proxyPacket.header.pid = requestPacket.header.pid;
    proxyPacket.header.recursionDesired = true;
    proxyPacket.header.recursionAvailable = true;
    proxyPacket.header.queryResponse = true;

    if (requestPacket.questions.size() == 1)
    {
        // Extract question from request packet
        QueryDns question = requestPacket.questions.front();
        requestPacket.questions.pop_back();
        std::cout << "Client query: " << question << std::endl;

        std::string domain = question.getDomainName();
        // Resolve DNS query recursively
        PacketDns lookupPacket = recursiveResolve(domain, question.getQueryType());

        if (lookupPacket.header.responseCode == RCode::NOERROR)
        {
            proxyPacket.questions.push_back(question);
            proxyPacket.header.responseCode = lookupPacket.header.responseCode;

            // Copy answers, authorities, and resources from lookup packet to proxy packet
            for (const auto &q : lookupPacket.answers)
            {
                proxyPacket.answers.push_back(q);
            }

            for (const auto &q : lookupPacket.authorities)
            {
                proxyPacket.authorities.push_back(q);
            }

            for (const auto &q : lookupPacket.resources)
            {
                proxyPacket.resources.push_back(q);
            }
        }
        else
        {
            // Set response code to server failure if lookup fails
            proxyPacket.header.responseCode = RCode::SERVFAIL;
        }
    }
    else
    {
        // Set response code to format error for malformed packet
        proxyPacket.header.responseCode = RCode::FORMERR;
    }

    // Prepare response buffer
    BufferBytePacket responseBuffer;
    proxyPacket.write(responseBuffer);

    std::cout << "Proxy packet:\n"
              << proxyPacket << std::endl;

    // Send response packet to client
    std::cout << "Forwarding response to client...\nBytes sent: " << udpSocket.send(responseBuffer, source.second.first, source.second.second)
              << std::endl;
}

PacketDns ProxyDns::recursiveResolve(std::string &domain, QueryType::QueryTypeEnum qtype)
{
    std::string nsIP = "198.41.0.4"; // Initial DNS server IP address
    std::string tempIP;
    std::string newNSName;

    while (true)
    {
        // Perform DNS lookup using the current DNS server
        std::cout << "Performing lookup of qtype: " << qtype << " domain: " << domain
                  << " with ns: " << nsIP << std::endl;
        std::string serverIP = nsIP;
        PacketDns response = performLookup(domain, qtype, serverIP);

        // If the lookup succeeds or domain does not exist, return the response
        if (!response.answers.empty() && (response.header.responseCode == RCode::NOERROR ||
                                          response.header.responseCode == RCode::NXDOMAIN))
        {
            return response;
        }

        // Check if there is a resolved name server IP address in the response
        tempIP = response.getResolvedNS(domain);
        if (!tempIP.empty())
        {
            nsIP = tempIP;
            continue;
        }

        // If no resolved name server IP, check if there is an unresolved name server name
        newNSName = response.getUnresolvedNS(domain);
        if (newNSName.empty())
        {
            return response;
        }

        // Resolve the unresolved name server name recursively
        PacketDns recursiveResponse = recursiveResolve(newNSName, QueryType::QueryTypeEnum::A);

        // Get a random A record from the recursive response to use as the new name server IP
        tempIP = recursiveResponse.getRandomARecord();
        if (!tempIP.empty())
            nsIP = tempIP;
        else
            return response;
    }
}
