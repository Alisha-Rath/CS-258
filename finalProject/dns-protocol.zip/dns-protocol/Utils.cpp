#include "Utils.hpp"

// Check if a string ends with a specific substring
bool hasEnding(std::string const &fullString, std::string const &ending)
{
    if (fullString.length() >= ending.length())
    {
        // Compare the ending substring with the end of the full string
        return (0 == fullString.compare(fullString.length() - ending.length(), ending.length(), ending));
    }
    else
    {
        // If the full string is shorter than the ending substring, it cannot end with it
        return false;
    }
}
