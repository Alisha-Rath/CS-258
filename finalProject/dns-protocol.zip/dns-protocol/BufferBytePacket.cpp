#include "BufferBytePacket.hpp"

// Function to throw an error when needed
[[noreturn]] void BufferBytePacket::raiseError()
{
    throw "Error!!!";
}

// Validate the position to ensure it's within buffer limits
void BufferBytePacket::validatePos(unsigned int position)
{
    if (position >= 512)
        raiseError(); // If position exceeds buffer size, throw error
}

// Get the current position in the buffer
unsigned BufferBytePacket::getPos() const { return pos; }

// Move the position by a certain number of steps
void BufferBytePacket::step(unsigned int steps) { pos += steps; }

// Move the position to a specific location
void BufferBytePacket::seek(unsigned int position) { pos = position; }

// Read a single byte from the buffer and update position
uint8_t BufferBytePacket::read()
{
    validatePos(pos);  // Ensure position is valid
    return buf[pos++]; // Read byte and move position forward
}

// Get a single byte from a specified position without updating position
uint8_t BufferBytePacket::getSingleByte(unsigned int position)
{
    validatePos(position); // Ensure position is valid
    return buf[position];  // Return byte from specified position
}

// Get a vector of bytes starting from a given position and of a specified length
std::vector<uint8_t> BufferBytePacket::getBytes(unsigned int start, unsigned int n)
{
    validatePos(start + n);      // Ensure position and length combination is valid
    std::vector<uint8_t> retVal; // Vector to store bytes
    for (unsigned i = start; i < start + n; i++)
        retVal.push_back(buf[i]); // Copy bytes into vector
    return retVal;                // Return vector of bytes
}

// Read two bytes from the buffer and combine them into a 16-bit value
uint16_t BufferBytePacket::read2Bytes() { return (read() << 8 | read()); }

// Read four bytes from the buffer and combine them into a 32-bit value
uint32_t BufferBytePacket::read4Bytes()
{
    return (read() << 24 | read() << 16 | read() << 8 | read());
}

// Read a domain name from the buffer and append it to the provided string
void BufferBytePacket::readDomainName(std::string &domain)
{
    unsigned curr = pos;

    bool jumped = false;

    unsigned len;

    uint8_t byte2;

    unsigned maxJumps = 5;

    unsigned jumpsSoFar = 0;

    std::string delimiter;

    std::vector<uint8_t> byteRangeBuf;

    do
    {

        if (jumpsSoFar > maxJumps)
            throw "Max jumps exceed while parsing domain name";

        len = getSingleByte(curr);

        if ((len & 0xC0) == 0xC0)
        {

            if (!jumped)
                seek(curr + 2);

            byte2 = getSingleByte(curr + 1);

            curr = ((len ^ 0xC0) << 8) | byte2;

            jumped = true;

            jumpsSoFar++;
        }
        else
        {

            curr++;

            if (!len)
                break;

            domain += delimiter;

            byteRangeBuf = getBytes(curr, len);

            domain += std::string(byteRangeBuf.begin(), byteRangeBuf.end());

            delimiter = ".";

            curr += len;
        }

    } while (len);

    if (!jumped)
        seek(curr);
}

// Write a single byte to the buffer at the current position
void BufferBytePacket::write1Byte(uint8_t val)
{
    validatePos(pos); // Ensure position is valid
    buf[pos++] = val; // Write byte and move position forward
}

// Write a 16-bit value to the buffer at the current position
void BufferBytePacket::write2Bytes(uint16_t val)
{
    write1Byte(static_cast<uint8_t>(val >> 8));   // Write high byte
    write1Byte(static_cast<uint8_t>(val & 0xFF)); // Write low byte
}

// Write a 32-bit value to the buffer at the current position
void BufferBytePacket::write4Bytes(uint32_t val)
{
    // TODO: try reusing write2Bytes()?

    // TODO: do we need to & each time?

    write1Byte(static_cast<uint8_t>(val >> 24) & 0xFF);

    write1Byte(static_cast<uint8_t>(val >> 16) & 0xFF);

    write1Byte(static_cast<uint8_t>(val >> 8) & 0xFF);

    write1Byte(static_cast<uint8_t>(val & 0xFF));
}

// Write a domain name to the buffer
void BufferBytePacket::writeDomainName(const std::string &domain)
{
    size_t prev = 0;

    size_t next = 0;

    char delimiter = '.';

    std::string label;

    unsigned len;

    std::string tempDomain = domain + ".";

    while ((next = tempDomain.find(delimiter, prev)) != std::string::npos)
    {

        label = tempDomain.substr(prev, next - prev);

        len = label.length();

        if (len > 63)
            throw "Label exceeds 63 characters";

        write1Byte(len);

        for (const char &c : label)
            write1Byte(static_cast<uint8_t>(c));

        prev = next + 1;
    }

    write1Byte(0); // terminate using a 0 indicating the end of label
}

// Set a single byte in the buffer at a specified position
void BufferBytePacket::set1Byte(unsigned int position, uint8_t val)
{
    validatePos(position); // Ensure position is valid
    buf[position] = val;   // Set byte at specified position
}

// Set a 16-bit value in the buffer starting from a specified position
void BufferBytePacket::set2Bytes(unsigned int position, uint16_t val)
{
    set1Byte(position, static_cast<uint8_t>(val >> 8));       // Set high byte
    set1Byte(position + 1, static_cast<uint8_t>(val & 0xFF)); // Set low byte
}
