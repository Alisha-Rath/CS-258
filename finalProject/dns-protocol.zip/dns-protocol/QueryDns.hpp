#ifndef QueryDns_H
#define QueryDns_H

#include <string>
#include <utility>
#include "BufferBytePacket.hpp"
#include "Utils.hpp"

class QueryType
{
private:
    static uint16_t qNum; // Static member variable to store the query number

public:
    enum QueryTypeEnum : uint16_t
    {
        UNKNOWN = 0, // Enum value for unknown query type
        A = 1,       // Enum value for A type query
        NS = 2,      // Enum value for NS type query
        CNAME = 5,   // Enum value for CNAME type query
        MX = 15,     // Enum value for MX type query
        AAAA = 28    // Enum value for AAAA type query
    };

    // Converts an integer to a QueryTypeEnum
    static QueryTypeEnum toEnum(uint16_t i)
    {

        switch (i)
        {

        case 1:
            return QueryTypeEnum::A;

        case 2:
            return QueryTypeEnum::NS;

        case 5:
            return QueryTypeEnum::CNAME;

        case 15:
            return QueryTypeEnum::MX;

        case 28:
            return QueryTypeEnum::AAAA;

        default:
        {

            qNum = i;

            return QueryTypeEnum::UNKNOWN;
        }
        }
    }

    // Converts a QueryTypeEnum to an integer
    static uint16_t toNum(QueryTypeEnum q)
    {

        if (q != QueryTypeEnum::UNKNOWN)
            return QueryTypeEnum(q);

        return qNum;
    }

    // Getter method for QueryTypeEnum
    QueryTypeEnum getQType()
    {
        return qtype;
    }

private:
    QueryTypeEnum qtype; // Query type enum member
};

class QueryDns
{
private:
    std::string name;               // Domain name
    QueryType::QueryTypeEnum qType; // Query type

public:
    // Constructors
    QueryDns(std::string n, QueryType::QueryTypeEnum qt) : name(std::move(n)), qType(qt) {}

    QueryDns(const QueryDns &q)
    {

        name = q.name;

        qType = q.qType;
    }

    // Method to read query from buffer
    void read(BufferBytePacket &buffer);

    // Overloaded stream insertion operator
    friend std::ostream &operator<<(std::ostream &os, const QueryDns &question);

    // Method to write query to buffer
    void write(BufferBytePacket &buffer) const;

    // Getter methods
    [[nodiscard]] std::string getDomainName() const { return name; }

    [[nodiscard]] QueryType::QueryTypeEnum getQueryType() const { return qType; }
};

#endif // QueryDns_H
