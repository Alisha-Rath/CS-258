#ifndef PacketDns_H
#define PacketDns_H

#include "HeaderDns.hpp"
#include "QueryDns.hpp"
#include "DnsSolution.hpp"
#include "BufferBytePacket.hpp"
#include "Utils.hpp"
#include <vector>
#include <iostream>

class PacketDns
{
public:
    HeaderDns header;                       // DNS header containing packet information
    std::vector<QueryDns> questions;        // Vector to store DNS questions
    std::vector<DnsSolution *> answers;     // Vector to store DNS answers
    std::vector<DnsSolution *> resources;   // Vector to store DNS resource records
    std::vector<DnsSolution *> authorities; // Vector to store authoritative DNS answers

    // Parse DNS packet from buffer
    void packetFromBuffer(BufferBytePacket &buffer);

    // Write DNS packet to buffer
    void write(BufferBytePacket &buffer);

    // Get a random A record from DNS answers
    std::string getRandomARecord();

    // Get all name servers for a given domain name
    std::vector<std::pair<std::string, std::string>> getAllNameServers(const std::string &domainName);

    // Get the resolved name server IP address for a given domain
    std::string getResolvedNS(const std::string &domain);

    // Get the unresolved name server IP address for a given domain
    std::string getUnresolvedNS(const std::string &domain);

    // Overload << operator for easy printing of PacketDns object
    friend std::ostream &operator<<(std::ostream &os, const PacketDns &packet);
};

#endif // PacketDns_H
