#ifndef BYTEPACKETBUFFER_H
#define BYTEPACKETBUFFER_H

#include <cstdint> // For uint8_t, uint16_t, uint32_t
#include <vector>  // For std::vector
#include <string>  // For std::string

// Class representing a buffer for byte packet operations
class BufferBytePacket
{
private:
    unsigned pos; // Current position within the buffer

public:
    uint8_t buf[512]; // Buffer to hold bytes (TODO: Confirm if 512 bytes are always needed)

    // Constructor
    BufferBytePacket() : pos(0), buf() {}

    // Get the current position in the buffer
    unsigned getPos() const;

    // Move the position by a specified number of steps
    void step(unsigned steps);

    // Move the position to a specified location
    void seek(unsigned position);

    // Read a single byte from the buffer and update the position
    uint8_t read();

    // Get a single byte from a specified position without updating the position
    uint8_t getSingleByte(unsigned position);

    // Get a vector of bytes starting from a given position and of a specified length
    std::vector<uint8_t> getBytes(unsigned start, unsigned n);

    // Read two bytes from the buffer and combine them into a 16-bit value
    uint16_t read2Bytes();

    // Read four bytes from the buffer and combine them into a 32-bit value
    uint32_t read4Bytes();

    // Read a domain name from the buffer and append it to the provided string
    void readDomainName(std::string &domain);

    // Validate if the position is within buffer limits
    void validatePos(unsigned position);

    // Function to throw an error
    [[noreturn]] void raiseError();

    // Write a single byte to the buffer at the current position
    void write1Byte(uint8_t val);

    // Write a 16-bit value to the buffer at the current position
    void write2Bytes(uint16_t val);

    // Write a 32-bit value to the buffer at the current position
    void write4Bytes(uint32_t val);

    // Write a domain name to the buffer
    void writeDomainName(const std::string &domain);

    // Set a single byte in the buffer at a specified position
    void set1Byte(unsigned position, uint8_t val);

    // Set a 16-bit value in the buffer starting from a specified position
    void set2Bytes(unsigned position, uint16_t val);
};

#endif // BYTEPACKETBUFFER_H
