#include "HeaderDns.hpp"
#include <iostream>

// Method to read DNS header from buffer
void HeaderDns::read(BufferBytePacket &buffer)
{
    // Read packet ID
    pid = buffer.read2Bytes();

    // Read flags
    uint16_t flags = buffer.read2Bytes();
    uint8_t lFlags = flags >> 8;   // Left flags
    uint8_t rFlags = flags & 0xFF; // Right flags

    // Parse left flags
    recursionDesired = lFlags & 1;
    truncatedMsg = (lFlags & (1 << 1)) > 0;
    authoritativeAns = (lFlags & (1 << 2)) > 0;
    opcode = (lFlags >> 3) & 0x0F;
    queryResponse = (lFlags & (1 << 7)) > 0;

    // Parse right flags
    responseCode = enumFromIdx<RCode>(rFlags & 0x0F);
    checkingDisabled = (rFlags & (1 << 4)) > 0;
    authedData = (rFlags & (1 << 5)) > 0;
    Z = (rFlags & (1 << 6)) > 0;
    recursionAvailable = (rFlags & (1 << 7)) > 0;

    // Read counts
    questions = buffer.read2Bytes();
    answers = buffer.read2Bytes();
    authoritativeEntries = buffer.read2Bytes();
    resourceEntries = buffer.read2Bytes();
}

// Overloaded stream insertion operator to output DNS header
std::ostream &operator<<(std::ostream &os, const HeaderDns &header)
{
    return os << "HeaderDns {" << std::endl
              << "\tpacket id: " << header.pid << std::endl
              << "\tqueryResponse: " << header.queryResponse << std::endl
              << "\topcode: " << (unsigned)header.opcode << std::endl
              << "\tauthoritativeAnswers: " << header.authoritativeAns << std::endl
              << "\ttruncatedMessage: " << header.truncatedMsg << std::endl
              << "\trecursionDesired: " << header.recursionDesired << std::endl
              << "\trecursionAvailable: " << header.recursionAvailable << std::endl
              << "\tZ: " << header.Z << std::endl
              << "\treponseCode: " << header.responseCode << std::endl
              << "\tcheckingDisabled: " << header.checkingDisabled << std::endl
              << "\tauthedData: " << header.authedData << std::endl
              << "\tquestions: " << header.questions << std::endl
              << "\tanswers: " << header.answers << std::endl
              << "\tauthoritativeEntries: " << header.authoritativeEntries << std::endl
              << "\tresourceEntries: " << header.resourceEntries << std::endl
              << "}" << std::endl;
}

// Method to write DNS header to buffer
void HeaderDns::write(BufferBytePacket &buffer) const
{
    // Write packet ID
    buffer.write2Bytes(pid);
    // Write flags
    buffer.write1Byte(
        (recursionDesired | (truncatedMsg << 1) | (authoritativeAns << 2) | (opcode << 3) | (queryResponse << 7)));
    // Write flags
    buffer.write1Byte(
        (responseCode | (checkingDisabled << 4) | (authedData << 5) | (Z << 6) | (recursionAvailable << 7)));
    // Write counts
    buffer.write2Bytes(questions);
    buffer.write2Bytes(answers);
    buffer.write2Bytes(authoritativeEntries);
    buffer.write2Bytes(resourceEntries);
}
